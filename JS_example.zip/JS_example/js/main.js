var btn = document.getElementById('btn');
btn.onclick = function (e) {
    e.preventDefaut();
	var text = document.querySelector('p.intro');
	text.classList.add('red');
	var img = document.querySelector('.desktop');
	img.style.display = 'none';
	document.querySelector ('future-value').style.marginLeft = '50px';
}

$(function () {
  $(window).scroll(function() {
	$('#learn .section-title').each(function() {
		var imagePos = $(this).offset().top;

		var topOfWindow = $(window).scrollTop();
		if (imagePos < topOfWindow+650) {
			$(this).addClass("fadeInLeft");
		}
	});
 });
})  

$(function () {
  $(window).scroll(function() {
	$('#learn .future-travel').each(function() {
		var imagePos = $(this).offset().top;

		var topOfWindow = $(window).scrollTop();
		if (imagePos < topOfWindow+650) {
			$(this).addClass("fadeInUp");
		}
	});
 });
})  

$(function () {
  $(window).scroll(function() {
	$('.future').each(function() {
		var imagePos = $(this).offset().top;

		var topOfWindow = $(window).scrollTop();
		if (imagePos < topOfWindow+650) {
			$(this).addClass("fadeInLeft");
		}
	});
 });
})  

$(function () {
  $(window).scroll(function() {
	$('.future-value').each(function() {
		var imagePos = $(this).offset().top;

		var topOfWindow = $(window).scrollTop();
		if (imagePos < topOfWindow+650) {
			$(this).addClass("fadeInRight");
		}
	});
 });
})  

$(function () {
  $(window).scroll(function() {
	$('.container').each(function() {
		var imagePos = $(this).offset().top;

		var topOfWindow = $(window).scrollTop();
		if (imagePos < topOfWindow+650) {
			$(this).addClass("fadeInUp");
		}
	});
 });
})  